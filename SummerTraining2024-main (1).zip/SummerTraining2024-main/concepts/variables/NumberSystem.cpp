#include<iostream>
using namespace std;
int main()
{ 
    /*
    cout<<"Hello World "<< var<< endl;
    int value= 7/0;
    cout<< " value : "<<value<<endl;
    return 0;
    int n1 ,n2;
    cout<<"Enter num1: ";
    cin>>n1;
    cout<<"Enter num2: ";
    //addition
    cout<<"addition: "<<(n1+n2)<<endl;
    */
    int n1,n2, n3,n4;
    n1= 15;  //decimal
    n2= 017; //octal
    n3= 0x0F; //hexadecimal
    n4=0b00001111; //binary
    cout<<"n1: "<<n1<<endl;
    cout<<"n2: "<<n2<<endl;
    cout<<"n3: "<<n3<<endl;
    cout<<"n4: "<<n4<<endl;
}