//object based programming 
#include<iostream>
//using namespace std; 
int main(){
   std::cout <<"hello world"; //when namespace is not used we use std:: with cin and cout
}