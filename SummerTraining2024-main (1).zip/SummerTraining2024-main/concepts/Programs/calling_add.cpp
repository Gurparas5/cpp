#include<iostream>
#include "D:\Summar Training 2024\headerfiles\add.h"
using namespace std;
int main(){
	cout<<"sum: "<<add(1,2)<<endl;
	cout<<"sum: "<<add(1,2,4);
}