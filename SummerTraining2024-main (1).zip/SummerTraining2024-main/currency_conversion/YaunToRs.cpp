#include<iostream>
using namespace std;
double YaunToRs(double Yaun){
    return Yaun*11.4;
}