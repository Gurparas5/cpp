#include<iostream>
using namespace std;
double RsToPound(double Rupees){
    return 0.0094*Rupees;
}