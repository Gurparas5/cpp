#include <iostream>
using namespace std;
double PoundToRs(double Pound){
    return Pound*106.98;
}