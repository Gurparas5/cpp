#include <iostream>
using namespace std;

double DollarToRs(double dollar){
    return dollar*83.53;
}