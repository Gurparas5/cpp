#include<iostream>
using namespace std;
double RsToYaun(double Rupees){
    return 0.087*Rupees;
}