#include <iostream>
using namespace std;

double RsToDollar(double value) {
    // Conversion logic here
    return value * 0.012; // Example conversion rate
}
